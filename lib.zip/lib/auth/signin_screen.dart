import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tremsolapp/okay/chatbot.dart';
import 'package:tremsolapp/okay/mainscreen.dart';

import 'forgot_password.dart';
import 'google_signin.dart';
import 'signup_screen.dart';
import '../currency/currencycon.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';



class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});

  @override
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Save FCM token to Firestore
  Future<void> saveFcmToken(String userId) async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    String? token = await messaging.getToken();

    if (token != null) {
      await FirebaseFirestore.instance.collection('users').doc(userId).update({
        'fcmToken': token,
      });
    }
  }

void signInUser() async {
  try {
    UserCredential userCredential =
        await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: _emailController.text.trim(),
      password: _passwordController.text.trim(),
    );

    // Save FCM token for the logged-in user
    /*if (userCredential.user != null) {
      await saveFcmToken(userCredential.user!.uid);
    }*/

    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isSignedIn', true);

    bool isFirstAccess = prefs.getBool('isFirstAccess') ?? true;

    // Check if the widget is still mounted before navigating
    if (!mounted) return;

    if (isFirstAccess) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => WelcomeScreenx()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const WelcomeScreenx()),
      );
    }
  } on FirebaseAuthException catch (e) {
    String errorMessage;

    switch (e.code) {
      case 'invalid-email':
        errorMessage = "Invalid email format. Please check your email.";
        break;
      case 'user-disabled':
        errorMessage = "This account has been disabled. Contact support.";
        break;
      case 'user-not-found':
        errorMessage = "No account found with this email.";
        break;
      case 'wrong-password':
        errorMessage = "Incorrect password. Please try again.";
        break;
      case 'too-many-requests':
        errorMessage =
            "Too many failed attempts. Try again later or reset your password.";
        break;
      case 'network-request-failed':
        errorMessage = "Network error. Check your connection and try again.";
        break;
      default:
        errorMessage = "Sign-in failed. Please try again.";
    }

    if (mounted) {

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
      
    }
  } catch (e) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("An unexpected error occurred.")),
      );
    }
  }
}


 
  static Future<void> signInWithFacebook(BuildContext context) async {
    try {
      // Show progress indicator while signing in
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      );

      // Trigger the Facebook sign-in flow
      final LoginResult loginResult = await FacebookAuth.instance.login();

      if (loginResult.status == LoginStatus.success) {
        // Extract the access token
        // Create a credential from the access token
        final OAuthCredential facebookAuthCredential =
            FacebookAuthProvider.credential(
                loginResult.accessToken!.tokenString);

        // Sign in with the credential
        UserCredential userCredential = await FirebaseAuth.instance
            .signInWithCredential(facebookAuthCredential);

        // Extract user info
        String? username = userCredential.user?.displayName;
        String? email = userCredential.user?.email;
        String? photoURL = userCredential.user?.photoURL;
        String? uid = userCredential.user?.uid; // User UID

        // Check if user already exists in Firestore
        DocumentSnapshot userDoc =
            await FirebaseFirestore.instance.collection('users').doc(uid).get();

        if (!userDoc.exists) {
          // Save user data to Firestore (first-time login only)
          await FirebaseFirestore.instance.collection('users').doc(uid).set({
            'username': username,
            'email': email,
            'profilepic': photoURL,
            'uid': uid, // Save UID in Firestore
          });
        }

        // Save sign-in state
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isSignedIn', true);

        // Check if it's the user's first access
        bool isFirstAccess = prefs.getBool('isFirstAccess') ?? true;

        Navigator.pop(context); // Close the progress indicator dialog

        if (isFirstAccess) {
          await prefs.setBool('isFirstAccess', false);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => WelcomeScreenx()),
          );
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const WelcomeScreenx()),
          );
        }
      } else {
        Navigator.pop(context); // Close the progress indicator dialog
        // Handle unsuccessful login
        debugPrint('Facebook Login Failed: ${loginResult.message}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Facebook Login Failed: ${loginResult.message}'),
          ),
        );
      }
    } catch (e) {
      Navigator.pop(context); // Close the progress indicator dialog
      // Handle exceptions
      debugPrint('Error during Facebook Login: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error during Facebook Login: $e')),
      );
    }
  }



//16 04 2025
String generateNonce([int length = 32]) {
  final charset = '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
  final random = Random.secure();
  return List.generate(length, (_) => charset[random.nextInt(charset.length)]).join();
}

String sha256ofString(String input) {
  final bytes = utf8.encode(input);
  final digest = sha256.convert(bytes);
  return digest.toString();
}

Future<void> signInWithApple() async {
  try {
    final rawNonce = generateNonce();
    final nonce = sha256ofString(rawNonce);

    final appleCredential = await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
      nonce: nonce,
    );

    final oauthCredential = OAuthProvider("apple.com").credential(
      idToken: appleCredential.identityToken,
      rawNonce: rawNonce,
        accessToken: appleCredential.authorizationCode, //<-- ADD THIS LINE
    );

    final userCredential = await FirebaseAuth.instance.signInWithCredential(oauthCredential);
    final user = userCredential.user;

    if (user == null) throw FirebaseAuthException(code: 'null-user');

    final uid = user.uid;
    final name = "${appleCredential.givenName ?? ''} ${appleCredential.familyName ?? ''}".trim();

    final userDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (!userDoc.exists) {
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'username': name.isNotEmpty ? name : 'Apple User',
        'email': user.email ?? appleCredential.email,
        'profilepic': user.photoURL,
        'uid': uid,
          'isWebuser': false,
      'timestamp': Timestamp.now(),
      'role': 1,
      });
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isSignedIn', true);

    bool isFirstAccess = prefs.getBool('isFirstAccess') ?? true;

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => isFirstAccess ? WelcomeScreenx() : const WelcomeScreenx(),
      ),
    );
 
  }
  
    catch (e) {
     debugPrint("Apple Sign-In Error: $e");
     if (mounted) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sorry! Sign-in with Apple is temporarily unavailable. Please attempt again at a later time.')),

          // const SnackBar(content: Text('Apple Sign-In failed.')),

        
      );
     }
   }
}

//16 04 2025





//added 08 -12 - 2024
  bool _isObscured = true;

//added 16 - 03 - 2025


void continueAsGuest() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  // Check if a guest UID already exists
  String? guestUid = prefs.getString('guestUid');

  if (guestUid == null) {
    // Generate a random UID for the guest
    guestUid = 'guest_${Random().nextInt(1000000)}';

    // Store it in SharedPreferences
    await prefs.setString('guestUid', guestUid);
  }

  // Save sign-in state
  await prefs.setBool('isSignedIn', true);

  // Navigate to the home screen or another relevant page
  Navigator.pushReplacement(
    context,
   // MaterialPageRoute(builder: (context) => const WelcomeScreenx()),
      MaterialPageRoute(builder: (context) => WelcomeScreenx()),
  );
}




  @override
  Widget build(BuildContext context) {

    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 80), // Add spacing at the top
              // Add logo at the top
              Image.asset(
                'assets/logo.png', // Path to the logo file in the assets folder
                height: 80, // Adjust the height of the logo
                fit: BoxFit.contain,
              ),
              const SizedBox(height: 50), // Spacing after the logo
              const Text(
                "Sign In",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
       const SizedBox(height: 50), // Spacing after the logo
            
        
              // Social media sign-in buttons
 if (Platform.isIOS)
GestureDetector(
  onTap: signInWithApple,
  child: Container(
     height: screenHeight * 0.055, // 6% of screen height
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 12),
    decoration: BoxDecoration(
      color: Colors.black,
      borderRadius: BorderRadius.circular(8),
      border: Border.all( // <-- Thick white outline
        color: Colors.white,
        width: 2,
      ),
    ),
    child: Stack(
      alignment: Alignment.center,
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Image.asset(
              'assets/apple_icon.png',
              height: 24,
              color: Colors.white,
            ),
          ),
        ),
        const Text(
          'Continue with Apple',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
      ],
    ),
  ),
),

GestureDetector(
  onTap: () async {
    final provider = Provider.of<GoogleSignInProvider>(context, listen: false);
    await provider.googleLogin(context);
  },
  child: Container(
    //height: 48,
        height: screenHeight * 0.05, // 6% of screen height
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(8),
      border: Border.all( // <-- Thick black outline
        color: Colors.black,
        width: 1.5,
      ),
    ),
    child: Stack(
      alignment: Alignment.center,
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Image.asset('assets/google_icon.png', height: 24),
          ),
        ),
        const Text(
          'Continue with Google',
          style: TextStyle(color: Colors.black, fontSize: 16),
        ),
      ],
    ),
  ),
),


  const SizedBox(height: 12),
Row(
  children: [
    const Expanded(
      child: Divider(
        thickness: 1,
        color: Colors.grey,
        endIndent: 12,
      ),
    ),
  const Text(
  "OR",
  style: TextStyle(
    fontSize: 14,
    color: Colors.grey,
    fontFamily: 'Montserrat', // <-- Your custom font name
    fontWeight: FontWeight.w600, // Optional: make it semi-bold
    letterSpacing: 1.2, // Optional: slight spacing for visual impact
  ),
),

    const Expanded(
      child: Divider(
        thickness: 1,
        color: Colors.grey,
        indent: 12,
      ),
    ),
  ],
),

              const SizedBox(height: 12),
        
              // Email TextField
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.email),
                  hintText: 'Email',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Password TextField
              TextField(
                controller: _passwordController,
                obscureText: _isObscured,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.lock),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isObscured ? Icons.visibility_off : Icons.visibility,
                      color: Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        _isObscured = !_isObscured;
                      });
                    },
                  ),
                  hintText: 'Password',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Remember me and Forgot password row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
              //     Row(
              //       children: [
              //       // Guest Sign In Button
              // TextButton(
              //   onPressed: continueAsGuest,
              //   child: const Text("Continue as Guest", 
              //   style: TextStyle(
              //     //fontSize: 16, 
              //   color: Colors.blue)),
              // ),
              //       ],
              //     ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ForgotPassword()),
                      );
                    }, // Forgot password function
                    child: const Text(
                      "Forgot password?",
                      style: TextStyle(color: Color.fromRGBO(234, 73, 42, 1.0)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Login Button
              SizedBox(
                width: double.infinity, // Full width like the TextField
                child: ElevatedButton(
                  onPressed: signInUser,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF002A5C),
                    minimumSize:
                        const Size.fromHeight(48), // Standard button height
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text(
                    "Sign In",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),

              const SizedBox(height: 16),
              // Sign Up Row
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Don't have an account? "),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SignUpScreen(),
                        ),
                      );
                    },
                    child: const Text(
                      "Sign Up",
                      style: TextStyle(color: Color.fromRGBO(234, 73, 42, 1.0)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
