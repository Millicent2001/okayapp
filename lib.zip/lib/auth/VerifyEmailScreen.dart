import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tremsolapp/currency/currencycon.dart';

class VerifyEmailScreen extends StatefulWidget {
  @override
  _VerifyEmailScreenState createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> {
  bool isEmailVerified = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    checkEmailVerified();
  }

  Future<void> checkEmailVerified() async {
    setState(() => isLoading = true);
    await FirebaseAuth.instance.currentUser!.reload();
    final user = FirebaseAuth.instance.currentUser!;
    setState(() {
      isEmailVerified = user.emailVerified;
      isLoading = false;
    });

    if (isEmailVerified) {
      // Optionally navigate to home or dashboard

      Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => CurrencyConverterScreen()),
    );
     
     
     /// Navigator.pushReplacementNamed(context, '/home'); // Change this to your home route
   
   
    }
  }

  Future<void> resendVerificationEmail() async {
    try {
      await FirebaseAuth.instance.currentUser!.sendEmailVerification();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Verification email sent again. Please check your inbox."),
        backgroundColor: Colors.green,
      ));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Error sending verification email. Try again later."),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Verify Your Email")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.email, size: 80, color: const Color(0xFF00195E)),
                  SizedBox(height: 20),
                  Text(
                    "A verification email has been sent to your email address.\nPlease verify to continue.",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 30),
                  ElevatedButton.icon(
                    onPressed: resendVerificationEmail,
                    icon: Icon(Icons.refresh,color:Color.fromRGBO(234, 73, 42, 1.0)),
                    label: Text("Resend Email",
                        style: TextStyle(
                
                    color: Color.fromRGBO(234, 73, 42, 1.0),
                  ),
                    ),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: checkEmailVerified,
                    icon: Icon(Icons.check_circle,color: Color.fromRGBO(234, 73, 42, 1.0)),
                    label: Text("I have verified",
                     style: TextStyle(
                
                    color: Color.fromRGBO(234, 73, 42, 1.0),
                  ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
