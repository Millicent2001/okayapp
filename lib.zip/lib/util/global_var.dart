//double totalAmount = 0.0;
