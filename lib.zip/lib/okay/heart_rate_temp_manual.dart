// import 'package:flutter/material.dart';

// class StressCheckPage extends StatefulWidget {
//   const StressCheckPage({super.key});

//   @override
//   State<StressCheckPage> createState() => _StressCheckPageState();
// }

// class _StressCheckPageState extends State<StressCheckPage> {
//   final TextEditingController heartRateController = TextEditingController();
//   final TextEditingController temperatureController = TextEditingController();
//   double stressScore = 0.0;
//   String result = "";

//   void checkStress() {
//     final hr = double.tryParse(heartRateController.text) ?? 0;
//     final temp = double.tryParse(temperatureController.text) ?? 0;

//     // Simple stress formula: HR > 100 or temp > 37.5 = stressed
//     stressScore = (hr / 200) + ((temp - 36) / 2);
//     if (stressScore > 1.2) {
//       result = "High Stress! Try calming exercises.";
//     } else if (stressScore > 0.8) {
//       result = "Moderate Stress. Take a short break.";
//     } else {
//       result = "Low Stress. You're doing fine!";
//     }
//     setState(() {});
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFFF1F7FF),
//       appBar: AppBar(title: const Text("Check Stress Level"), backgroundColor: Colors.blueAccent),
//       body: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text("Enter your vitals:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//             const SizedBox(height: 10),
//             TextField(
//               controller: heartRateController,
//               keyboardType: TextInputType.number,
//               decoration: const InputDecoration(labelText: "Heart Rate (bpm)", border: OutlineInputBorder()),
//             ),
//             const SizedBox(height: 10),
//             TextField(
//               controller: temperatureController,
//               keyboardType: TextInputType.number,
//               decoration: const InputDecoration(labelText: "Body Temp (°C)", border: OutlineInputBorder()),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: checkStress,
//               style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
//               child: const Text("Check Stress"),
//             ),
//             const SizedBox(height: 20),
//             if (result.isNotEmpty)
//               Container(
//                 padding: const EdgeInsets.all(16),
//                 decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
//                 child: Text(result, style: const TextStyle(fontSize: 18)),
//               ),
//           ],
//         ),
//       ),
//     );
//   }
// }
