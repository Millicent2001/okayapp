import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class StressCheckPage extends StatefulWidget {
  const StressCheckPage({super.key});

  @override
  State<StressCheckPage> createState() => _StressCheckPageState();
}

class _StressCheckPageState extends State<StressCheckPage> {
  final TextEditingController heartRateController = TextEditingController();
  final TextEditingController temperatureController = TextEditingController();
  final TextEditingController moodController = TextEditingController();

  double stressScore = 0.0;
  String result = "";
  String aiAdvice = "";
  bool loadingAI = false;

  void checkStress() {
    final hr = double.tryParse(heartRateController.text) ?? 0;
    final temp = double.tryParse(temperatureController.text) ?? 0;

    // Simple stress formula
    stressScore = (hr / 200) + ((temp - 36) / 2);
    if (stressScore > 1.2) {
      result = "High Stress! Try calming exercises.";
    } else if (stressScore > 0.8) {
      result = "Moderate Stress. Take a short break.";
    } else {
      result = "Low Stress. You're doing fine!";
    }
    setState(() {});
  }

  Future<void> getAIAdvice() async {
    setState(() {
      loadingAI = true;
      aiAdvice = "";
    });

    final hr = heartRateController.text.trim();
    final temp = temperatureController.text.trim();
    final mood = moodController.text.trim();

    final String apiKey =
        "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";

    try {
      final response = await http.post(
        Uri.parse("https://openrouter.ai/api/v1/chat/completions"),
        headers: {
          "Authorization": "Bearer $apiKey",
          "Content-Type": "application/json",
          "HTTP-Referer": "yourapp.com",
          "X-Title": "Stress Tips App"
        },
        body: jsonEncode({
          "model": "deepseek/deepseek-r1-0528:free",
          "messages": [
            {
              "role": "system",
              "content":
                  "You are a child psychology expert. Give practical, gentle stress management advice based on vitals."
            },
            {
              "role": "user",
              "content":
                  "Heart Rate: $hr bpm, Temperature: $temp °C, Mood: $mood. Provide advice in 2-3 sentences for reducing stress in children."
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          aiAdvice = data["choices"][0]["message"]["content"];
        });
      } else {
        setState(() {
          aiAdvice = "Error: ${response.statusCode} - ${response.body}";
        });
      }
    } catch (e) {
      setState(() {
        aiAdvice = "Error: $e";
      });
    } finally {
      setState(() {
        loadingAI = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F7FF),
      appBar: AppBar(
        title: const Text("Check Stress Level"),
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Enter your vitals:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              TextField(
                controller: heartRateController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Heart Rate (bpm)", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: temperatureController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Body Temp (°C)", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: moodController,
                decoration: const InputDecoration(labelText: "Mood (optional)", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: checkStress,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                child: const Text("Check Stress"),
              ),
              const SizedBox(height: 20),
              if (result.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                  child: Text(result, style: const TextStyle(fontSize: 18)),
                ),
              const SizedBox(height: 20),
              if (result.isNotEmpty)
                ElevatedButton(
                  onPressed: loadingAI ? null : getAIAdvice,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: loadingAI
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white))
                      : const Text("Get AI Advice"),
                ),
              const SizedBox(height: 20),
              if (aiAdvice.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                  child: Text(aiAdvice, style: const TextStyle(fontSize: 16)),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
