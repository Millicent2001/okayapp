//use google map to show locations of health professionals

