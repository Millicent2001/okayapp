import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class GamesScreen extends StatelessWidget {
  const GamesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFDFF6E0), // Light calming green background
      appBar: AppBar(
        backgroundColor: const Color(0xFFDFF6E0),
        iconTheme: const IconThemeData(color: Color(0xFF1B4332)), // Deep green
        elevation: 0,
        title: const Text(
          'Stress-Relief Games',
          style: TextStyle(
            color: Color(0xFF1B4332),
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Color(0xFF1B4332)),
            onPressed: () {
              // Navigator.push(context, MaterialPageRoute(builder: (_) => const GameSearchPage()));
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('games_okay')
            .orderBy('viewscount', descending: true)
            .limit(3)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());

          if (snapshot.hasError || !snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text('No games found', style: TextStyle(color: Color(0xFF1B4332), fontSize: 16)),
            );
          }

          final topGames = snapshot.data!.docs;

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
                child: Text(
                  'Top 3 Games',
                  style: TextStyle(
                    color: Color(0xFF1B4332),
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 140,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: topGames.length,
                  itemBuilder: (context, index) {
                    final game = topGames[index].data() as Map<String, dynamic>;

                    return GestureDetector(
                      onTap: () {
                        launchUrl(Uri.parse(game['gamelocation']));
                        _incrementViewCount(game['id']);
                      },
                      child: Container(
                        width: 110,
                        margin: const EdgeInsets.only(right: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black12,
                              blurRadius: 6,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 40,
                              backgroundImage: CachedNetworkImageProvider(game['image']),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              game['gametitle'],
                              style: const TextStyle(
                                color: Color(0xFF1B4332), // Dark green for readability
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              '+${game['viewscount']} views',
                              style: const TextStyle(
                                color: Color(0xFF2D6A4F), // Softer green
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('games_okay')
                      .orderBy('viewscount', descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());

                    if (snapshot.hasError || !snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return const Center(child: Text('No games available', style: TextStyle(color: Color(0xFF1B4332))));
                    }

                    final games = snapshot.data!.docs;
                    final currentUserId = FirebaseAuth.instance.currentUser?.uid;

                    return ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: games.length,
                      itemBuilder: (context, index) {
                        final game = games[index].data() as Map<String, dynamic>;
                        final isLiked = (game['likes'] as List).contains(currentUserId);

                        return Card(
                          margin: const EdgeInsets.only(bottom: 16),
                          color: const Color(0xFF122F46), // Deep navy background
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                            leading: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CachedNetworkImage(
                                imageUrl: game['image'],
                                width: 50,
                                height: 50,
                                fit: BoxFit.cover,
                                placeholder: (_, __) => const Icon(Icons.videogame_asset, color: Colors.white30),
                                errorWidget: (_, __, ___) => const Icon(Icons.videogame_asset, color: Colors.white30),
                              ),
                            ),
                            title: Text(
                              game['gametitle'],
                              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 4.0),
                              child: Wrap(
                                spacing: 12,
                                children: [
                                  _iconWithText(Icons.remove_red_eye, game['viewscount'].toString()),
                                  GestureDetector(
                                    onTap: () => _handleCommentTap(context, game['id']),
                                    child: _iconWithText(Icons.comment, game['commentcount'].toString()),
                                  ),
                                  GestureDetector(
                                    onTap: () => _shareGame(game['gametitle'], game['gamelocation'], game['image']),
                                    child: const Icon(FontAwesomeIcons.shareFromSquare, size: 14, color: Color(0xFFB7E4C7)),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      isLiked ? Icons.thumb_up : Icons.thumb_up_off_alt,
                                      color: isLiked ? Colors.lightBlueAccent : Colors.grey,
                                      size: 18,
                                    ),
                                    onPressed: () {
                                      if (currentUserId != null) {
                                        toggleLike(game['id'], isLiked);
                                      } else {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          const SnackBar(content: Text('Sign in to like games')),
                                        );
                                      }
                                    },
                                  ),
                                ],
                              ),
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.play_circle_fill, color: Colors.green, size: 30),
                              onPressed: () {
                                launchUrl(Uri.parse(game['gamelocation']));
                                _incrementViewCount(game['id']);
                              },
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _iconWithText(IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: Colors.grey, size: 14),
        const SizedBox(width: 4),
        Text(text, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ],
    );
  }

  void _handleCommentTap(BuildContext context, String gameId) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please sign in to comment')),
      );
    } else {
      // Navigator.push(context, MaterialPageRoute(builder: (_) => GameCommentPage(gameId)));
    }
  }

  void _incrementViewCount(String gameId) {
    FirebaseFirestore.instance.collection('games_okay').doc(gameId).update({
      'viewscount': FieldValue.increment(1),
    });
  }

  Future<void> _shareGame(String title, String location, String imageUrl) async {
    final shareText = """
🎮 Discover amazing stress-relief games on Okay App!

🏷 $title
📍 $location

🌟 Download Okay App now and play games that reduce stress!

#OkayApp #StressFreeGaming
""";
    await Share.share(shareText, subject: "Game Alert: $title");
  }

  void toggleLike(String gameId, bool isLiked) async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    final gameRef = FirebaseFirestore.instance.collection('games_okay').doc(gameId);

    if (isLiked) {
      await gameRef.update({'likes': FieldValue.arrayRemove([userId])});
    } else {
      await gameRef.update({'likes': FieldValue.arrayUnion([userId])});
    }
  }
}
