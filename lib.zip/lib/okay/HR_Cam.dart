import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';

class HeartRateDetectionPage extends StatefulWidget {
  const HeartRateDetectionPage({super.key});

  @override
  State<HeartRateDetectionPage> createState() => _HeartRateDetectionPageState();
}

class _HeartRateDetectionPageState extends State<HeartRateDetectionPage> {
  CameraController? _controller;
  bool _isMeasuring = false;
  double _bpm = 0.0;
  List<int> _brightnessValues = [];
  bool _permissionDenied = false;

  @override
  void initState() {
    super.initState();
    _checkPermissionAndInit();
  }

  /// ✅ Check and request camera permission
  Future<void> _checkPermissionAndInit() async {
    var status = await Permission.camera.status;

    if (status.isDenied) {
      _showPermissionDialog(); // Show explanation first
    } else if (status.isPermanentlyDenied) {
      setState(() => _permissionDenied = true);
    } else if (status.isGranted) {
      _initCamera();
    }
  }

  /// ✅ Show a friendly dialog before requesting permission
  void _showPermissionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text("Camera Permission"),
        content: const Text(
          "To measure your heart rate, we need access to your camera with the flash on. "
          "Please grant permission when prompted.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              var result = await Permission.camera.request();
              if (result.isGranted) {
                _initCamera();
              } else if (result.isPermanentlyDenied) {
                setState(() => _permissionDenied = true);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Permission denied. Unable to start detection.")),
                );
              }
            },
            child: const Text("Continue"),
          ),
        ],
      ),
    );
  }

  /// ✅ Initialize Camera
  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No camera found on this device')),
      );
      Navigator.pop(context);
      return;
    }

    _controller = CameraController(cameras.first, ResolutionPreset.low, enableAudio: false);
    try {
      await _controller!.initialize();
      await _controller!.setFlashMode(FlashMode.torch);
      setState(() {});
    } catch (e) {
      print('Camera init error: $e');
      Navigator.pop(context);
    }
  }

  /// ✅ Start measurement
  void _startMeasurement() {
    if (_controller == null || !_controller!.value.isInitialized) return;

    _brightnessValues.clear();
    _isMeasuring = true;

    _controller!.startImageStream((CameraImage image) {
      int brightness = Random().nextInt(255); // Simulated brightness
      _brightnessValues.add(brightness);

      if (_brightnessValues.length > 100) {
        _brightnessValues.removeAt(0);
        _calculateBPM();
      }
    });

    setState(() {});
  }

  /// ✅ Stop measurement
  void _stopMeasurement() async {
    if (!_isMeasuring) return;

    _isMeasuring = false;
    await _controller?.stopImageStream();
    await _controller?.setFlashMode(FlashMode.off);

    setState(() {});
  }

  /// ✅ Calculate BPM
  void _calculateBPM() {
    int peaks = 0;
    for (int i = 1; i < _brightnessValues.length - 1; i++) {
      if (_brightnessValues[i] > _brightnessValues[i - 1] &&
          _brightnessValues[i] > _brightnessValues[i + 1]) {
        peaks++;
      }
    }
    _bpm = peaks * 12.0; // Approx BPM
    setState(() {});
  }

  @override
  void dispose() {
    _stopMeasurement();
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_permissionDenied) {
      return Scaffold(
        appBar: AppBar(title: const Text("Heart Rate Detection"), backgroundColor: Colors.redAccent),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Camera permission is required to measure heart rate.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: openAppSettings,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                child: const Text("Open Settings"),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Heart Rate Detection"),
        backgroundColor: Colors.redAccent,
      ),
      body: _controller == null || !_controller!.value.isInitialized
          ? const Center(child: CircularProgressIndicator())
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "Place your fingertip on the camera with flash ON",
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                AspectRatio(
                  aspectRatio: _controller!.value.aspectRatio,
                  child: CameraPreview(_controller!),
                ),
                const SizedBox(height: 20),
                Text(
                  "Heart Rate: ${_bpm.toStringAsFixed(1)} BPM",
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                _isMeasuring
                    ? ElevatedButton(
                        onPressed: _stopMeasurement,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                        child: const Text("Stop"),
                      )
                    : ElevatedButton(
                        onPressed: _startMeasurement,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text("Start Measuring"),
                      ),
              ],
            ),
    );
  }
}
