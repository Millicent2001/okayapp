import 'package:flutter/material.dart';

class HealthDataPage extends StatelessWidget {
  const HealthDataPage({super.key});

  @override
  Widget build(BuildContext context) {
    // ✅ Mock sample health data
    final mockHealthData = [
      {
        "title": "Heart Rate",
        "value": "78 bpm",
        "icon": Icons.favorite,
        "color": Colors.redAccent,
        "subtitle": "Normal resting heart rate"
      },
      {
        "title": "Steps",
        "value": "8,432",
        "icon": Icons.directions_walk,
        "color": Colors.blue,
        "subtitle": "Daily goal: 10,000"
      },
      {
        "title": "Blood Pressure",
        "value": "118 / 78 mmHg",
        "icon": Icons.monitor_heart,
        "color": Colors.deepPurple,
        "subtitle": "Healthy range"
      },
      {
        "title": "Calories Burned",
        "value": "540 kcal",
        "icon": Icons.local_fire_department,
        "color": Colors.orange,
        "subtitle": "Active calories today"
      },
      {
        "title": "Sleep",
        "value": "7h 15m",
        "icon": Icons.bedtime,
        "color": Colors.indigo,
        "subtitle": "Last night"
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Health Overview'),
        backgroundColor: Colors.green,
      ),
      backgroundColor: const Color(0xFFF5F7FA),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Today's Summary",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            Expanded(
              child: ListView.builder(
                itemCount: mockHealthData.length,
                itemBuilder: (context, index) {
                  final data = mockHealthData[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 6,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: (data['color'] as Color).withOpacity(0.1),
                          child: Icon(data['icon'] as IconData,
                              color: data['color'] as Color, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                data['title'] as String,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                data['subtitle'] as String,
                                style: const TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          data['value'] as String,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
