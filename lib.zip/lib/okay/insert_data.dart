import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class InsertGamesSamplePage extends StatelessWidget {
  const InsertGamesSamplePage({super.key});

  Future<void> insertSampleGames() async {
    final firestore = FirebaseFirestore.instance;

    final stressReliefGames = [
      {
        'gametitle': 'Calm Puzzle',
        'gamelocation': 'https://poki.com/en/g/puzzle-relax',
        'image': 'https://i.imgur.com/xyz123p.jpg',
        'viewscount': 120,
        'commentcount': 15,
        'likes': [],
      },
      {
        'gametitle': 'Zen Garden',
        'gamelocation': 'https://poki.com/en/g/zen-garden',
        'image': 'https://i.imgur.com/xyz123z.jpg',
        'viewscount': 180,
        'commentcount': 22,
        'likes': [],
      },
      {
        'gametitle': 'Color Therapy',
        'gamelocation': 'https://poki.com/en/g/color-therapy',
        'image': 'https://i.imgur.com/xyz123c.jpg',
        'viewscount': 150,
        'commentcount': 19,
        'likes': [],
      },
      {
        'gametitle': 'Breath & Relax',
        'gamelocation': 'https://poki.com/en/g/breath-and-relax',
        'image': 'https://i.imgur.com/xyz123b.jpg',
        'viewscount': 200,
        'commentcount': 30,
        'likes': [],
      },
      {
        'gametitle': 'Soothing Sounds',
        'gamelocation': 'https://poki.com/en/g/soothing-sounds',
        'image': 'https://i.imgur.com/xyz123s.jpg',
        'viewscount': 95,
        'commentcount': 10,
        'likes': [],
      },
    ];

    try {
      for (var game in stressReliefGames) {
        await firestore.collection('games_okay').add({
          ...game,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
      print("✅ Stress-relief games inserted successfully!");
    } catch (e) {
      print("❌ Error inserting games: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Insert Stress-Relief Games"),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          onPressed: () async {
            await insertSampleGames();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Stress-relief games inserted successfully!")),
            );
          },
          child: const Text(
            "Insert 5 Stress-Relief Games",
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
