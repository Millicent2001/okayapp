import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tremsolapp/custom_ad/ad_widget.dart';
import 'auxilliary/notification_service.dart';
import 'shop/shop_screen.dart';
import 'social/favorite.dart';
import 'social/general_test.dart';
import 'social/social_media_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;

  final List<Widget> _children = [
    const ShopScreen(), // Online Shop section
    const SocialMediaScreen(), // Social Media section
    //  const DiscoverPage()
  ];

  final List<String> _titles = [
    "Online Shop",
    "Social Media",
  ];

  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this, // Add this to provide the TickerProvider
    );

   //commented 26 02 2025
   // NotificationService.initialize(context);

  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
    _controller.forward().then((value) => _controller.reverse());
  }

  Future<void> _signOut() async {
    await FirebaseAuth.instance.signOut();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isSignedIn', false);
    Navigator.of(context).pushReplacementNamed('/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _children[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF002A5C), // Navy blue from logo
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: const Color(0xFFFF4E00), // Orange from logo
          unselectedItemColor: Colors.white54,
          currentIndex: _currentIndex,
          onTap: onTabTapped,
          items: [
            BottomNavigationBarItem(
              icon: _currentIndex == 0
                  ? Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.shopping_bag_outlined,
                              color: const Color(0xFFFF4E00)),
                          SizedBox(width: 5),
                          // Text("Shop",
                          //     style: TextStyle(color: const Color(0xFFFF4E00))),
                        ],
                      ),
                    )
                  : Icon(Icons.shopping_bag_outlined),
              label: 'Store',
            ),
            BottomNavigationBarItem(
              icon: _currentIndex == 1
                  ? Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.group_outlined,
                              color: const Color(0xFFFF4E00)),
                          SizedBox(width: 5),
                          // Text("Social",
                          //     style: TextStyle(color: const Color(0xFFFF4E00))),
                        ],
                      ),
                    )
                  : Icon(Icons.group_outlined),
              label: 'Social',
            ),
          ],
        ),
      ),
    );
  }
}
