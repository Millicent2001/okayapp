import 'dart:async';
import 'package:flutter/material.dart';
import 'package:tremsolapp/auth/signup_screen.dart';
import 'homescreen.dart';
import 'auth/signin_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isSignedIn = prefs.getBool('isSignedIn') ?? false;

    Timer(Duration(seconds: 3), () {
      // Set a 3-second delay
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => isSignedIn ? HomeScreen() : SignInScreen(),
          //  builder: (context) => isSignedIn ? SignUpScreen() : SignInScreen(),
        ),
      );
    });
  }

 @override
Widget build(BuildContext context) {
  return Container(
    color: Colors.white,
    alignment: Alignment.center,
    child: SizedBox(
      width: 200,
      height: 200,
      child: Image.asset("assets/okayappicon3.png", fit: BoxFit.contain),
    ),
  );
}

}
