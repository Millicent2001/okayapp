import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:tremsolapp/custom_ad/ad_widget.dart';
import 'package:tremsolapp/internet_connect/app_shell.dart';
import 'package:tremsolapp/okay/chatbot.dart';
import 'package:tremsolapp/okay/mainscreen.dart';

import 'auth/google_signin.dart';
import 'auth/signin_screen.dart';
import 'homescreen.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

    // ✅ Lock orientation to portrait only
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  //  DeviceOrientation.portraitDown, // Optional
  ]);

  // Initialize Facebook Login for Web/Desktop
  FacebookAuth.instance.webAndDesktopInitialize(
   // appId: "4008888439344593",
      appId: "526801647139656",
    cookie: true,
    xfbml: true,
    version: "v18.0",
    
  );

  await initializeNotifications();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => GoogleSignInProvider()),
      ],
      child: MyApp(),
    ),
  );

 //signOutUser();
}

 Future<void> signOutUser() async {
   await FirebaseAuth.instance.signOut();
}



Future<void> initializeNotifications() async {
  const AndroidInitializationSettings androidSettings =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  const DarwinInitializationSettings iosSettings = DarwinInitializationSettings();

  const InitializationSettings settings = InitializationSettings(
    android: androidSettings,
    iOS: iosSettings,
  );

  await flutterLocalNotificationsPlugin.initialize(
    settings,
    onDidReceiveNotificationResponse: (NotificationResponse response) {
      if (response.payload != null) {
        print('Notification payload: ${response.payload}');
      }
    },
  );

  await requestNotificationPermissions();
}

Future<void> requestNotificationPermissions() async {
  if (await Permission.notification.isDenied) {
    final status = await Permission.notification.request();
    if (status.isGranted) {
      print('✅ Notification permission granted.');
    } else {
      print('❌ Notification permission denied.');
    }
  }

  flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
      ?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
     // home: AuthCheck(),
         home: WelcomeScreenx(),
      routes: {
        '/login': (context) => const SignInScreen(),
        '/home': (context) => const StressChatPage(),
         '/adModal': (context) => AdModalPage(),
       
      },
    );
  }
}

class AuthCheck extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }else if (snapshot.hasData) {
  return const AppShell(); // Wraps HomeScreen and handles offline state
}

        
        else {
          return const SignInScreen();
        }
      },
    );
  }
}